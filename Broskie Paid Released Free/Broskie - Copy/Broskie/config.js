const config = {
    token: "MTIxOTQ2ODI4MjE2ODQ3NTY3OA.Gnxk5v.BEeS53fzKJzF3fCscg-hhkFiu4jNjLp9UUfF3g",//`MTIzMTQ3MTcyOTAwNDY0NjQ1MQ.GiYBfG.95faZAedM0sHRgZDLPjyz8gDXPfB-VxVKs5al8`,
    prefix: "$",
    captchaKey: "9d0106ffe0d7cf628438d8d295432b8d",
    webhook: `https://discord.com/api/webhooks/1234029584119234641/6tlRACghmY2hA8Irfqp1lSNvg70nrhNjxctQRI3yxk7vNQ2NlkVeXaus6qiDSJsUT7cl`,
    captchaHook: `https://discord.com/api/webhooks/1233317556085850144/leX1fnC9B2uzre7y6jflzz1G6fYs9VTU6wLrwjHSQbaKtqc9nJOolOhCIVuIck-KfNWc`,
    owners: ["1181516983351640114"]
}


module.exports = config