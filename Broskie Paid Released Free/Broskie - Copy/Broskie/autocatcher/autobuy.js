console.clear();
process.title = `Broskie Autobuy`;
 const tokens =
``.split(
  "\n"
);
const { Client } = require("discord.js-selfbot-v13");
const wait = require("node:timers/promises").setTimeout;
const fs = require("fs");
const { solveHint } = require("pokehint");
require("colors");
const broskies = require("./cr");
let valid = [];
const msgs = fs.readFileSync(`data/msgs.txt`, `utf-8`).split("\n");
async function start() {
  for (let i = 1; i < broskies.length; i++) {
    //if (i > 0) continue;
    const client = new Client();
    await new Promise((resolve) => {
      client.login(broskies[i]).catch((err) => {
        console.log(`Unable to login into ${i + 1}`.red);
        resolve();
      });
      let caught = false;
      client.on("ready", async () => {
        console.log(`[${i + 1}] Connected to ${client.user.tag}`.green);
        let guild = client.guilds.cache.find(
          (x) => x.memberCount > 3 && x.memberCount < 7
        );
        if (!guild) return console.log(`Unable to find guild for ${i + 1}`.red);
        let channel = guild.channels.cache.find((x) => x.type == "GUILD_TEXT");
        await channel.send(`<@716390085896962058> pick charmander`);
        await wait(3000);
        for (let i = 0; i < 40; i++) {
            if(caught) break;
          await channel.send(
            `${msgs[Math.floor(Math.random() * msgs.length)]}`
          );
          await wait(1500);
        }
      });
      client.on("messageCreate", async (message) => {
        if (message.embeds.length > 0) {
          if (
            message.embeds[0]?.footer &&
            message.embeds[0].footer.text.includes("Terms") &&
            message?.components[0]?.components[0]
          ) {
            message.clickButton().catch((err) => {
              console.log(err);
            });
          }
          if (message.embeds[0].title.includes("has appeared")) {
            message.channel.send(`<@716390085896962058> hint`);
          }
        }
        if(message.content.includes(`You've`)) {
            caught = true
        }
        if (message.content.includes("The pokémon is")) {
          let poke = await solveHint(message);
          message.channel.send(`<@716390085896962058> c ${poke[0]}`);
        }
        if (
          message.content.includes(`Congratulations`) &&
          message.content.includes(client.user.id)
        ) {
            caught = true
          message.channel.send(`<@716390085896962058> m a 0 40000`);
          resolve();
        }
        if (message.content.includes(`Are you sure`)) {
          if (message?.components?.length > 0) {
            message.clickButton().catch((err) => {
              console.log(err);
            });
          }
        }
        if (message.content.includes(`Listed`)) {
          let id = message.content.split("#").reverse()[0].replace(").", ``);
          console.log(id);
          getMoney(id)
          resolve()
        }
      });
    });
  }
}

async function sec() {
  await wait(2000);
  let total = 0;
  for (let i = 9; i < tokens.length; i++) {
    const client = new Client();
    
    await new Promise((resolve) => {
      setTimeout(() => {
        resolve()
      }, 15000);
      client.login(tokens[i].trim()).catch((Err) => {
        console.log(`Unable to login into ${i + 1}`.red);
        resolve();
      });
      client.on("ready", async () => {
        console.log(`Connected to ${client.user.tag}`.green);
        const guild = client.guilds.cache.find(
          (x) => x.memberCount > 1 && x.memberCount < 12
        );
        if (!guild) return console.log(`Cant locate guild for ${i + 1}`.red);
        let channel = guild.channels.cache.find((x) => x.type == "GUILD_TEXT");
        channel.send(`<@716390085896962058> bal`);
        console.log(`${i + 1} Checking bal`, client.user.tag, client.token);
      });
      client.on("messageCreate", async (message) => {
        if (message.content.includes("You purchased")) {
          resolve();
          return;
          await wait(1000);
          console.log(`${i + 1} Resolved!`);
          console.log(message.url);
          if (message?.components?.length > 0)
            message.clickButton().catch((err) => {
              console.log(err);
            });
          else console.log(`Cant click btn!`);
          resolve();
          client.destroy();
        }
        if (message.embeds.length > 0) {
          let embed = message.embeds[0];
          if (embed.title.includes("balance")) {
            if (embed.fields.length > 0) {
              let bal = parseInt(embed.fields[0].value.replace(/,/g, ``));
              total += bal;
              console.log(bal, total);
              if (bal > 1000) {
                console.log(`${i + 1} Uploading`);
                buyNext(bal, message.channel);
              } else resolve();
            } else resolve();
          }
        }
      });
    });
  }
}
async function spam(channel, i, loop) {
  ++i;
  console.log(`Spam: ${i}`.gray);
  await channel.send(`${msgs[Math.floor(Math.random() * msgs.length)]}`);
  if (loop) {
    await wait(Math.floor(Math.random() * (3000 - 1350 + 1)) + 1350);
    await spam(channel, i, loop);
  }
}
/*
const bot = new Client();
bot.login(
  
);

bot.on("ready", async () => {
  console.log(`Connected to ${bot.user.tag}`);
});
*/

async function getMoney(id) {
  const channel = await bot.channels.fetch(`1221470366594105467`);
  const collector = channel.createMessageCollector();
  collector.on("collect", async (msg) => {
    if (msg.content.includes("Are you sure")) {
      if (msg?.components?.length > 0)
        msg.clickButton().catch((err) => {
          console.log(err);
        });
    }
  });
  channel.send(`<@716390085896962058> m b ${id}`);
}
const bot = new Client();
bot.login(
  "null"
);
let last = 0;
let ar = [];
bot.on("messageCreate", async (message) => {
  //Listed your **Level 6 Yanma<:female:1207734084210532483> (61.83%) No. 147** on the market for **1** Pokécoins (Listing #32906044).
  if (message.content.includes(`Listed`)) {
    let id = message.content.split("#").reverse()[0].replace(").", ``);
    console.log(id);
  }
});
bot.on("ready", async () => {
  await wait(1000);
  console.log(`Logged in to ${bot.user.tag}`);
});
async function buyNext(price, cs) {
  const channel = await bot.channels.fetch(`1221470366594105467`);
  const collector = channel.createMessageCollector();
  collector.on("collect", async (msg) => {
    if (msg.content.includes("Are you sure")) {
      if (msg?.components?.length > 0)
        msg.clickButton().catch((err) => {
          console.log(err);
        });
    }
    if (msg.content.includes(`Listed`)) {
      let id = msg.content.split("#").reverse()[0].replace(").", ``);
      console.log(id);
      console.log(`Purchased!`);
      cs.send(`<@716390085896962058> m buy ${id}`);
      let x = cs.createMessageCollector();
      x.on("collect", async (msg2) => {
        if (msg2.content.includes("Are you sure")) {
            console.log(msg2.content)
          if (msg2?.components?.length > 0)
            msg2.clickButton().catch((err) => {
              console.log(err);
            });
        }
      });
      collector.stop();
    }
  });
  let x = await channel.send(`<@716390085896962058> m a 0 ${price}`);
}
sec();

