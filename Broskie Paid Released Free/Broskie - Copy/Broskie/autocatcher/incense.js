const tokens =
  `MTE2OTUzNTU2ODAzMjU4MzcyMQ.GOk50A.z2wVgwMGX00hCipztkzk0GK-KH29tHwXNzedF8
MTE2MjkzODg1NTc1OTA0MDY3Mg.GfVWNr.m-ctwtDOXRef5IExzGLxo6REQc6Sf4wpmpeC0M
MTE2Mjk0NTA4NTc5MzY0MDU1OA.GrS54y.IrbR-vDogMuAo6nAyeqS_FxpFodSCxMBchAbwA
MTE2MTA3OTk2OTM5NzYxMjU2NA.GlumSX.pD7oNfWgXtQTvQUxtsik7h43yg-LC6AKu1lLyI
MTE5NzM2NTE4MTQ1ODY4NTk5Mg.GK19OT.045Xc3CZ6UJqRLJRBcep719L6WwAfNvlA2BU4A
MTE2MTA4ODIzMTQ3MTg2MTkyMQ.G-RYWQ.6UyuHUkVJHr011ArqD7rtT-GQknK0qSf9uwQ3s
MTE2OTUzNTcyNTIwOTkxNTQwMQ.GWBFWg.5j-BVnoOYAkte6LL7grrWVJEMsyErdPwe9mze8
MTE2OTUzNTczMTEyODA5NDgyMQ.GtfkvK.iZrROk4RQ-Dcv03TDFNTE9JuNApvIXqy4ysOL8
MTE2OTUzNTU3NjAyNjkxNDg0MA.G9CzbO.FL50whAY8w-rmbaSRVL_o0asVtJ9d2ZIjBRqgU
MTE2Mjk4OTUzNDQzNTM0ODYzMQ.Gc-zt-.ayCFtK9536a3UjUOh9R4v9yREDL1zY721n9Pmo
MTE2Mjk0NTA3NjEwOTAwMDgxNg.GCxHiF.Zs6CCGUz_CFO871feWUMkWr_C1Iqk_Ti8hqHYM
MTE2OTUzNTczODgxNjI1NDA1Mg.GIlBxC.dnnDZhuL6mFdESatK3UCW5fF6PdL7lLxkwvgEY
MTE2Mjk0NTA3NTg3ODMxNDA4NA.GoV1m4.bJZBUzb9ofEB7PQ58yWlIN7nLTf8kR25HvJyN8
MTE2Mjk0NDk4MTYyMzkwMjI1MA.GIcu-7.YzWYmjxWZ4bsHG_sUSWplzg7FGgqGzt5x9Q-5I
MTE2OTUzNTU2Mjg3MzU4MTYwOQ.GNfXS6.LsVU9rZBj4ub8zn70IcsYs1J2DLXj5hDypHZp0
MTE5Mjc4NjkwMDU2MjQ4NTMwOQ.GAe5f5.SzSLgjrIKB7B4OUDPib2VD2lunTXfQESGgj8ac
MTE2MzE2NjgwNzY0MTgyMTI0NQ.Gi9bZc.9amc5wdw1kp5_hauxBu8jJwXM7LafAf1yap9jg
MTE2MzE2Njc5OTU0MjYxNjEyNA.GFWmDx.m85O49mgZ9WRdPWvGsL4KRzxC6AcyUUS7FTDEM
MTE2MzE2Njc5NzE1MTg4MzI2NQ.G8Oj8j.As2Un3V3dr4wxhykF-LATumqMsGav7rmeu11G8
MTE2Mjk0NTAxMzEyMzE0MTY2Mw.GmP4Lx.wzmXQs3v_6Fi3ScJ5Xa4gagC8aCF4cPKIXvkvY
MTE2Mjk0NTA0NzgzNTE5MzQxNA.GZ9M9y.uj-0ETxON467O_nmCnSZ8J7wg9QYP4NaoBT21I
MTE2MzE2NjgwMzk1MDg1MDE3MQ.GX6etM.1zCW35iw7hO6xQN_B55BKCSYYSaYAUIHrKWNSg
MTE2Mjk0NTA1OTE0NzIyNzE3Nw.G72D2s.oLiVoRTXd65BhbefrWRWVxvkO9-8wHyK_i1Lmk
MTE2OTUzNjAxODk2NjM5Mjg2NQ.GsMZni.O97w7-7upXxRdGR6QWvirexObJJu9mCMsgCrzo
MTE2Mjk0NTA4ODQ2NTQyMDM0OA.G4n3Oz.TMu1Lcyta8PnrpIoC_bOrFfmN8mMlpFxdpWyl0
MTE2OTUzNjA0MDQ4NzM2MjU4MA.GelnaQ.Dpi34mWfZGQZNY84-aaIuWif95SwSLOiuiEYtg
MTE2MzE2NjgwODM4MDAzMDk5Ng.GaarkA.-YR18eSvWoqNMsg4iOXfzLZjRuyNsi-pZlpCXA
MTE2OTUzNTU2MzAxNjE3OTczMw.GR1E20.EznhDShGl334SWy1YxpR18XUEFm1wWXS70WoVE
MTE2Mjk4OTUyOTUwMjg1NTE3OA.GM3ot2.ElO7uF1SgPrz39gbhgo7TcLo0wX0yu0CAq-kxw
MTE2MjkzODk0MDU0MjY5MzUwNw.GfCG1G.3qgq0GpVDTxTzRYTSDpkxj1CJPMAK-cJKVsS8k
MTE2MzE2NjgxMjExMjk0NTIwMw.GZjGTN.b0-kbf4WdJVooKrfbkJRjXRj7v7lLz4G7CMpAQ
MTE2OTUzNTcxNTMxMTM2MjE0Mg.GJO1HM.WM4Dh0Eq52O5SsEGLm01BOpTcdZwYOMdR46KdQ
MTE2OTUzNTcyNTY2NzA5ODYzNA.GESbe_.OrVqXdD9i5IYk3mx6FZCf8z5YWTVhjFkjR-5J0
MTE2MzE2Njc5NjA0ODc3NzI0Ng.GwmXkL.f1-jo3O1VhfD25tibiTTuJByN7bVxoBd-gKQ3M
MTE2MzI1MTUzOTY3NTIwNTcyMw.GVdr2Z.SAMWt7RntN8BxXG_FNY0zvbhnxzNo7_Ka_KL3Q
MTE2OTUzNjAyNjU5MTYzMzQ4MA.Ge3WYO.naiSo2lUTsdRREe2nKN63g8IK3NFn7wqrJqsBs
MTE2MzE2Njc5NjQwOTQ3MTA1Nw.G2LJPT.r39DUZPTunrgqNaDGwdOe2iAHenm8vw6dbhS7Y
MTE2MzE2NjgwMzYwNjkxMzE1NQ.GdT6J1.iCEEFaJ18trkbx0J9rXo3s8nqFWxQHMfNmDuIo
MTE2OTUzNjA1ODczMjU4OTA2Ng.GmqxQ5.yECxBnFdeDfsXAOILM95Mnsww5Qev4NDqoTW1k
MTE2Mjk4OTU5Mjk0MTY5NTA4Ng.GTD_sd.lgVdqhxwgtYxxNC5VrDYsOmmVanMSGP3Frnxzw
MTE5Mjc4NjgxMjAxNjUzMzU3NQ.GSFsaH.aQhHOVTTeLBV5G-6ewUkYAlxCk94CYauKHQy6Y
MTE2OTUzNTcyODM5NzU5ODc1Mg.G6D0Hk.dphSMnYWd1GvDcuGMp4g5G1V7uiFJaBqQEAilY
MTE2MzI1MzkwNDUzNzAzODg3OA.GDa0k0.jCZtA_CMdMk7hzzec0uO35oKHU5YS1Le6Oe81A
MTE2Mjk0NTA2MjQ0Mzk1MDEwMQ.GNNFwU.GB2tIDxje1VLrsivzr6vENWu-THm5oxDHlEYPE`.split(
    "\n"
  );
const { Client } = require("discord.js-selfbot-v13");
const wait = require("node:timers/promises").setTimeout;
require("colors");
for (let i = 1; i < tokens.length; i++) {
  //if (i > 1) continue;
  let purchased = 0;
  const client = new Client();
  client
    .login(tokens[i].trim())
    .catch((err) => console.log(`Invalid token at ${i + 1}`));

  client.on("ready", async () => {
    console.log(`Connected in as ${client.user.tag}`);
    //await buyShards(client, 200, i);
    await massIncense(client, 4, i);
  });
  client.on("messageCreate", async (message) => {
    //Are you sure you want to exchange **200** Pokécoins for **1** shards? Shards are non-transferable and non-refundable!
    if (message.content.includes(`you want to exchange`)) {
      message.clickButton();
    }
    if (message.content.includes(`shards!`)) {
      console.log(
        `[${message.guild.name.cyan} | ${i + 1}]` +
          ` Purchased shards in ${message.channel.name} for ${client.user.tag}`
            .green
      );
    }
    if (
      message.content.includes(`purchased`) &&
      !message.content.includes(`shards`)
    ) {
      purchased++;
      console.log(
        `[${message.guild.name.cyan} | ${i + 1}]` +
          ` Purchased incense in ${message.channel.name}`.green
      );
    }
    if (
      message.content.toLowerCase().includes(`.incense`) &&
      message.content.includes(client.user.id)
    ) {
      const channels = message.guild.channels.cache.filter((x) =>
        x.name.includes(`incense`)
      );
      if (channels.size > 0) {
        message.react(`👼`);
        for (let x = 0; x < channels.size; x++) {
          let channel = channels.at(x);
          await channel.send(`<@716390085896962058> buy incense`);
          await wait(1000);
        }
        message.react(`✅`);
      }
    }
  });
  setTimeout(() => {
    let str = `${client?.user?.tag}: ${purchased}`;
    if (purchased == 4) console.log(str.green);
    else console.log(str.red, client?.token);
  }, 20000);
}

async function buyShards(client, amount, i) {
  let guild = client.guilds.cache.find(
    (x) => x.memberCount > 2 && x.memberCount < 12
  );
  if (!guild)
    console.log(
      `Unable to find guild for ${i + 1}`.red,
      client.guilds.cache.map((x) => x.name)
    );
  const channel =
    guild.channels.cache.find((x) => x.name.includes("spawn")) ||
    guild.channels.cache.find((x) => x.type == "GUILD_TEXT");
  channel.send(`<@716390085896962058> buy shards ${amount}`);
}
async function massIncense(client, count, i) {
  let guild = client.guilds.cache.find(
    (x) => x.memberCount > 2 && x.memberCount < 12
  );
  if (!guild)
    console.log(
      `Unable to find guild for ${i + 1}`.red,
      client.guilds.cache.map((x) => x.name)
    );
  let channels = Array.from(guild.channels.cache.values()).filter((x) =>
    x.name.includes("incense")
  );
  if (channels.length < count) {
    let left = count - channels.length;
    let list = Array.from(guild.channels.cache.values()).filter(
      (x) => !x.name.includes("incense") && x.type == "GUILD_TEXT"
    );
    for (let i = 0; i < left; i++) channels.push(list[i]);
  }
  for (let i = 0; i < count; i++) {
    try {
      let channel = channels[i];
      await channel.send(`<@716390085896962058> buy incense`);
      console.log(`Sent purchase req for ${client.user.tag}`.yellow);
      await wait(500);
    } catch (error) {
      console.log(`Unable to purchase incense in ${guild.name}/${i + 1}`.red);
    }
  }
}
