const config = {
    token: "MTI0MTY2NDY1NjgwNDkzNzczOA.G9izcf.-1rUormVJbpvh5ar3tASl5E7O6cMmteSks8mas",//`MTIzMTQ3MTcyOTAwNDY0NjQ1MQ.GiYBfG.95faZAedM0sHRgZDLPjyz8gDXPfB-VxVKs5al8`,
    prefix: "$",
    captchaKey: "9d0106ffe0d7cf628438d8d295432b8d",
    webhook: `https://discord.com/api/webhooks/1241671949969784872/BbvGTwRb2PqmwN_B5p-IS967L27Hz8d1Yf4fE7dt5uVfQsba8XAYjaJFPt_RPobTeTxC`,
    captchaHook: `https://discord.com/api/webhooks/1241671685057417297/WfEMzl13iEvCWofd846rACyqwKHjmMeqW_Qv-YvN0SE-Uddqm12HQLy_gShGbHg8wBIb`,
    owners: ["1004675600931364924"]
}


module.exports = config